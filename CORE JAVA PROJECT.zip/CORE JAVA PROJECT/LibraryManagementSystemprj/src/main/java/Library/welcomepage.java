package Library;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class welcomepage extends JFrame
{
	static welcomepage frame;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run() 
			{
				try
				{
					frame= new welcomepage();
					frame.setTitle("Welcome to Library Management System window");
					frame.setVisible(true);
					frame.setBounds(100, 100, 450, 300);
					frame.setContentPane(new JLabel(new ImageIcon("\\C:\\Users\\ELCOT\\Desktop\\COREJAVA MINI PROJECT FOLDER\\lib_pic-2.jpg")));
					
					 
				} 
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}
	
}
