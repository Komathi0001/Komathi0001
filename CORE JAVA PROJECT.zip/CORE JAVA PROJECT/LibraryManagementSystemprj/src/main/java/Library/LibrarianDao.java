package Library;
import java.sql.*;
public class LibrarianDao
{

	
	public static int save(int id,String name,String password,String email,String address,String city,int contact)
	{
		int status=0;
		try
		{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into librarian(id,name,password,email,address,city,contact) values(?,?,?,?,?,?,?)");
			ps.setInt(1,id);
			ps.setString(2,name);
			ps.setString(3,password);
			ps.setString(4,email);
			ps.setString(5,address);
			ps.setString(6,city);
			ps.setInt(7,contact);
			status=ps.executeUpdate();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return status;
	}
	public static int delete(int id)
	{
		int status=0;
		try
		{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from librarian where id=?");
			ps.setInt(1,id);
			status=ps.executeUpdate();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return status;
	}

	public static boolean validate(int id,String name,String password)
	{
		boolean status=false;
		try
		{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from librarian where name=? and password=?");
			ps.setInt(1,id);
			ps.setString(2,name);
			ps.setString(3,password);
			ResultSet rs=ps.executeQuery();
			status=rs.next();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return status;
	}
	public static int save(String id,String name, String password, String email, String address, String city, String contact) 
	{
		// TODO Auto-generated method stub
		return 0;
	}

}
