-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 06, 2022 at 05:08 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_online_smartphone_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `bonaza`
--

CREATE TABLE `bonaza` (
  `festival_id` int(11) NOT NULL,
  `festivalname` varchar(30) NOT NULL,
  `discount%` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `custid` varchar(6) NOT NULL,
  `custnm` varchar(50) NOT NULL,
  `pwd` varchar(10) NOT NULL,
  `e_mail` varchar(400) NOT NULL,
  `address` varchar(500) NOT NULL,
  `phno` bigint(20) NOT NULL,
  `pincode` int(11) NOT NULL,
  `state` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`custid`, `custnm`, `pwd`, `e_mail`, `address`, `phno`, `pincode`, `state`) VALUES
('C-1001', '.mathi', '.mathi', 'ko123@gmail.com', 'chennai', 8976545699, 600128, 'good\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `or_id` int(11) NOT NULL,
  `custid` int(11) NOT NULL,
  `prid` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `totalprice` int(100) NOT NULL,
  `discount` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`or_id`, `custid`, `prid`, `qty`, `totalprice`, `discount`) VALUES
(21, 1001, 1, 25, 20000, 10);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `prid` varchar(10) NOT NULL,
  `prnm` varchar(100) NOT NULL,
  `pic` varchar(1000) NOT NULL,
  `description` longtext NOT NULL,
  `qty` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`prid`, `prnm`, `pic`, `description`, `qty`, `price`) VALUES
('PR-1002', 'oppo', 'oppo2.png', 'By comparing them side by side with equivalent models* of better-known brands, we hope this can give you a better idea of the overall performance and quality of OPPO phones. ... Entry level - OPPO AX5S v Samsung A11. Value for money	4.2	3.4 Ease of use	4.3	3.7 Battery life	4.5	4.4 Camera quality	3.7	3.5 Hardware	3.9	3.5', 35, 15000),
('PR-1003', 'vivo', 'vivo1.jpg', 'good and  more advantage', 34, 19000),
('PR-1004', 'oppo', 'oppo1.jpg', 'By comparing them side by side with equivalent models* of better-known brands, we hope this can give you a better idea of the overall performance and quality of OPPO phones. ... Entry level - OPPO AX5S v Sam. Value for money	4.2	3.4 Ease of use	4.3	3.7 Battery life	4.5	4.4 Camera quality	3.7	3.5 Hardware	3.9	3.5', 25, 10000),
('PR-1005', 'realme', 'realme1.jpg', 'By comparing them side by side with equivalent models* of better-known brands, we hope this can give you a better idea of the overall performance and quality of REALME phones. ... Entry level - REALME AX5S v Samsung A11. Value for money	4.2	3.4 Ease of use	4.3	3.7 Battery life	4.5	4.4 Camera quality	3.7	3.5 Hardware	3.9	3.5', 22, 12000),
('PR-1006', 'apple', 'apple1.jpg', 'By comparing them side by side with equivalent models* of better-known brands, we hope this can give you a better idea of the overall performance and quality of APPLY phones.  Entry level - APPLE AX5S v Samsung A11. Value for money	4.2	3.4 Ease of use	4.3	3.7 Battery life	4.5	4.4 Camera quality	3.7	3.5 Hardware	3.9	3.5', 35, 15000),
('PR-1007', 'vivo', 'vivo1.jpg', 'By comparing them side by side with equivalent models* of better-known brands, we hope this can give you a better idea of the overall performance and quality of VIVO phones. ... Entry level - vivo v5 AX5S v Samsung A11. Value for money	4.2	3.4 Ease of use	4.3	3.7 Battery life	4.5	4.4 Camera quality	3.7	3.5 Hardware	3.9	3.5', 30, 18000),
('PR-1008', 'samsung j5', 'samsung.png', 'By comparing them side by side with equivalent models* of better-known brands, we hope this can give you a better idea of the overall performance and quality of samsung phones. ... Entry level - samsung AX5S v Samsung A11. Value for money	4.2	3.4 Ease of use	4.3	3.7 Battery life	4.5	4.4 Camera quality	3.7	3.5 Hardware	3.9	3.5', 28, 11000),
('PR-1009', 'oppo', 'oppo2.jpg', 'By comparing them side by side with equivalent models* of better-known brands, we hope this can give you a better idea of the overall performance and quality of OPPO phones. ... Entry level - OPPO AX5S v Samsung A11. Value for money	4.2	3.4 Ease of use	4.3	3.7 Battery life	4.5	4.4 Camera quality	3.7	3.5 Hardware	3.9	3.5', 12, 17000),
('PR-1010', 'samsung', 'all samsung mobile.png', 'By comparing them side by side with equivalent models* of better-known brands, we hope this can give you a better idea of the overall performance and quality of  SAMSUNG phones. ... Entry level - SAMSUNG AX5S v Samsung A11. Value for money	4.2	3.4 Ease of use	4.3	3.7 Battery life	4.5	4.4 Camera quality	3.7	3.5 Hardware	3.9	3.5', 15, 10000),
('PR-1011', 'vivo', 'vivo3.jpg', 'By comparing them side by side with equivalent models* of better-known brands, we hope this can give you a better idea of the overall performance and quality of OPPO phones. ... Entry level - OPPO AX5S v Samsung A11. Value for money	4.2	3.4 Ease of use	4.3	3.7 Battery life	4.5	4.4 Camera quality	3.7	3.5 Hardware	3.9	3.5', 14, 20000),
('PR-1012', 'oppo', 'oppo3.jpg', 'By comparing them side by side with equivalent models* of better-known brands, we hope this can give you a better idea of the overall performance and quality of OPPO phones. ... Entry level - OPPO AX5S v Samsung A11. Value for money	4.2	3.4 Ease of use	4.3	3.7 Battery life	4.5	4.4 Camera quality	3.7	3.5 Hardware	3.9	3.5', 12, 12000),
('PR-1013', 'realme', 'realall.jpg', 'By comparing them side by side with equivalent models* of better-known brands, we hope this can give you a better idea of the overall performance and quality of  REALME phones. ... Entry level - REALME  AX5S v Samsung A11. Value for money	4.2	3.4 Ease of use	4.3	3.7 Battery life	4.5	4.4 Camera quality	3.7	3.5 Hardware	3.9	3.5', 12, 16000);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `usr_mail_id` varchar(300) NOT NULL,
  `u_pwd` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`usr_mail_id`, `u_pwd`) VALUES
('admin@spring.com', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bonaza`
--
ALTER TABLE `bonaza`
  ADD PRIMARY KEY (`festival_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`custid`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`or_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`prid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`usr_mail_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
